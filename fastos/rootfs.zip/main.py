import ubin.svc_mgr as svc
import ubin.shell as sh

# Here you can register background services
# svc.register("dummy", lambda : print("dummy service running"))

print("Starting autostart services...")
svc.start_autostart_services()

print("Entering FastOS Neon shell...")
sh.shell_loop()
