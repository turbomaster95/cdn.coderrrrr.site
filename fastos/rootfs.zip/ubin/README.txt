Hi There!

This folder (/ubin) is where you'll keep your installed applications once you have downloaded it!

The files you can put here include:
- .py applications
- .pyc applications
- .fos FastOS Compiled Applications 

